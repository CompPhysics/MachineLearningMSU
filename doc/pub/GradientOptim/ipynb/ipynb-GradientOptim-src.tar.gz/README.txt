This IPython notebook GradientOptim.ipynb does not require any additional
programs.
