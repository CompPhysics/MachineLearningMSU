This IPython notebook svm.ipynb does not require any additional
programs.
