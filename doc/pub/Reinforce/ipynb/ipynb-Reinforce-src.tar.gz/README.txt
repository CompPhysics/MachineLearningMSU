This IPython notebook Reinforce.ipynb does not require any additional
programs.
